business_effective_date=2009-05-19-10:19:26
delete=all
changes_only=no
changes_from_date=1970-01-01-00:00:00
attribute_scope=full
sensitive_information_removed=yes
extract_date=2013-03-25-16:13:06
